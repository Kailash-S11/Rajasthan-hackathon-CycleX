#!/usr/bin/env python
import os
from flask import Flask, abort, request, jsonify, g, url_for
from flask.ext.sqlalchemy import SQLAlchemy
from flask.ext.httpauth import HTTPBasicAuth
from passlib.apps import custom_app_context as pwd_context
from itsdangerous import (TimedJSONWebSignatureSerializer
                          as Serializer, BadSignature, SignatureExpired)
import datetime
from dateutil.relativedelta import relativedelta
# initialization
app = Flask(__name__)
app.config['SECRET_KEY'] = 'the quick brown fox jumps over the lazy dog'
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:1111@localhost/CycleEx'
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////test.db'
#app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:1111@localhost/CycleX'

app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True

# extensions
db = SQLAlchemy(app)

authOff = HTTPBasicAuth()
authCli = HTTPBasicAuth()


class CycleIssueLog(db.Model):
    __tablename__ = 'CyclesIssueLog'
    id = db.Column(db.Integer, primary_key=True)
    cycleId = db.Column(db.Integer, db.ForeignKey("Cycles.id"))
    #userId = db.Column(db.String(32), db.ForeignKey("Users.emailId"))
    bhamashahId = db.Column(db.String(32))
    memberId = db.Column(db.String(32))
    fromStation = db.Column(db.String(32), db.ForeignKey("AuthUsers.username"))
    toStation = db.Column(db.String(32), db.ForeignKey("AuthUsers.username"), default=None)
    issueDateTime = db.Column(db.DateTime, default=datetime.datetime.now)
    submitDateTime = db.Column(db.DateTime, default=None)

@app.route('/issueCycle', methods=['POST'])
@authOff.login_required
def issueCycle():
    cycleId = request.json.get('cycleId')
    fromStation = request.json.get('fromStation')
    bhamashahId = request.json.get('bhamashahId')
    memberId = request.json.get('memberId')

    if cycleId is None or fromStation is None or bhamashahId is None or memberId is None:
        abort(400)
    if CycleIssueLog.query.filter_by(bhamashahId=bhamashahId, memberId=memberId, toStation=None, submitDateTime=None).first() is not None:
        print("error");
        return ("", 202)
    cycle = Cycle.query.filter_by(id=cycleId).first();
    cycle.status = 1

    log = CycleIssueLog();
    log.cycleId = cycleId
    log.bhamashahId = bhamashahId
    log.memberId = memberId;
    log.fromStation = fromStation

    db.session.add(log)
    db.session.commit()

    return (str(cycle.id), 201);

@app.route('/submitCycle/<username>/<int:cycleId>')
@authOff.login_required
def submitCycle(cycleId, username):

    if cycleId is None:
        abort(400)


    cycle = Cycle.query.filter_by(id=cycleId).first();
    cycle.status = 0
    cycle.currentStation = username

    log = CycleIssueLog.query.filter_by(cycleId=cycleId, toStation=None, submitDateTime=None).first();

    log.submitDateTime = datetime.datetime.now();
    log.toStation = username
    db.session.commit()
    diff = relativedelta(log.submitDateTime, log.issueDateTime)

    return jsonify({"years":diff.years, "months":diff.months, "days":diff.days, "hours":diff.hours, "minutes":diff.minutes, "bhamashahId":log.bhamashahId, "memberId": log.memberId });


class Cycle(db.Model):
    __tablename__ = 'Cycles'
    id = db.Column(db.Integer, primary_key=True)
    ownerId = db.Column(db.String(32), db.ForeignKey("Users.emailId"))
    model = db.Column(db.String(32))
    currentStation = db.Column(db.String(32), db.ForeignKey("AuthUsers.username"))
    status = db.Column(db.Integer, default=0)


class AuthUser(db.Model):
    __tablename__ = 'AuthUsers'
    id = db.Column(db.Integer, primary_key=True)

    username = db.Column(db.String(32), index=True, unique=True)
    password_hash = db.Column(db.String(200))
    mobile = db.Column(db.String(10))
    address = db.Column(db.String(100))
    city = db.Column(db.String(32))
    district = db.Column(db.String(32))
    state = db.Column(db.String(32))
    pin = db.Column(db.String(6))
    latitude =  db.Column(db.Float())
    longitude = db.Column(db.Float())


    def hash_password(self, password):
        self.password_hash = pwd_context.encrypt(password)

    def verify_password(self, password):
        return pwd_context.verify(password, self.password_hash)

    def generate_auth_token(self, expiration=600):
        s = Serializer(app.config['SECRET_KEY'], expires_in=expiration)
        return s.dumps({'id': self.id})

    @staticmethod
    def verify_auth_token(token):
        s = Serializer(app.config['SECRET_KEY'])
        try:
            data = s.loads(token)
        except SignatureExpired:
            return None    # valid token, but expired
        except BadSignature:
            return None    # invalid token
        user = AuthUser.query.get(data['id'])
        return user


class User(db.Model):
    __tablename__ = 'Users'
    id = db.Column(db.Integer, primary_key=True)
    firstName = db.Column(db.String(32))
    lastName = db.Column(db.String(32))
    gender = db.Column(db.String(10))
    emailId = db.Column(db.String(32), index=True, unique=True)
    mobileNo = db.Column(db.String(10))
    address = db.Column(db.String(100))
    city = db.Column(db.String(32))
    district = db.Column(db.String(32))
    state = db.Column(db.String(32))
    pin = db.Column(db.String(6))
    password_hash = db.Column(db.String(200))

    def hash_password(self, password):
        self.password_hash = pwd_context.encrypt(password)

    def verify_password(self, password):
        return pwd_context.verify(password, self.password_hash)

    def generate_auth_token(self, expiration=600):
        s = Serializer(app.config['SECRET_KEY'], expires_in=expiration)
        return s.dumps({'id': self.id})

    @staticmethod
    def verify_auth_token(token):
        s = Serializer(app.config['SECRET_KEY'])
        try:
            data = s.loads(token)
        except SignatureExpired:
            return None    # valid token, but expired
        except BadSignature:
            return None    # invalid token
        user = User.query.get(data['id'])
        return user


@authOff.verify_password
def verify_password(username_or_token, password):
    # first try to authenticate by token
    #print(username_or_token)
    #print(password)
    user = AuthUser.verify_auth_token(username_or_token)
    if not user:
        # try to authenticate with username/password
        user = AuthUser.query.filter_by(username=username_or_token).first()
        if not user or not user.verify_password(password):
            return False
    g.user = user
    return True


@authCli.verify_password
def verify_password(username_or_token, password):
    # first try to authenticate by token
    user = User.verify_auth_token(username_or_token)
    if not user:
        # try to authenticate with username/password
        user = User.query.filter_by(emailId=username_or_token).first()
        if not user or not user.verify_password(password):
            return False
    g.user = user
    return True


@app.route('/addOff', methods=['POST'])
def new_user():
    username = request.json.get('username')
    password = request.json.get('password')
    mobile = request.json.get('mobile')
    address = request.json.get('address')
    city = request.json.get('city')
    district = request.json.get('district')
    state = request.json.get('state')
    pin = request.json.get('pin')
    latitude = request.json.get('latitude')
    longitude = request.json.get('longitude')

    if username is None or password is None or mobile is None or address is None or city is None or district is None or state is None or pin is None:
        abort(400)    # missing arguments
    if AuthUser.query.filter_by(username=username).first() is not None:
        abort(400)    # existing user

    user = AuthUser(username=username)

    user.hash_password(password)
    user.mobile = mobile
    user.address = address
    user.city = city
    user.district = district
    user.state = state
    user.pin = pin
    user.latitude = latitude
    user.longitude = longitude
    db.session.add(user)
    db.session.commit()

    return (jsonify({"username": user.username, "mobile" : user.mobile, "address" : user.address, "city" :user.city, "district" : user.district, "state" : user.state, "pin" : user.pin, "latitude":user.latitude, "longitude":user.longitude}), 201, {'Location': url_for('get_authUser', id=user.id, _external=True)})

@app.route('/addCli', methods=['POST'])
@authOff.login_required
def new_userCli():

    firstName = request.json.get('firstName')
    lastName = request.json.get('lastName')
    gender = request.json.get('gender')
    emailId = request.json.get('emailId')
    mobileNo = request.json.get('mobileNo')
    address = request.json.get('address')
    city = request.json.get('city')
    district = request.json.get('district')
    state = request.json.get('state')
    pin = request.json.get('pin')
    password = request.json.get('password')

    if firstName is None or lastName is None or gender is None or emailId is None or mobileNo is None or address is None or city is None or district is None or state is None or pin is None or password is None:
        abort(400)    # missing arguments
    if User.query.filter_by(emailId=emailId).first() is not None:
        abort(400)    # existing user

    user = User()
    user.emailId = emailId;
    user.firstName = firstName
    user.lastName = lastName
    user.gender = gender
    user.emailId = emailId
    user.mobileNo = mobileNo
    user.address = address
    user.city = city
    user.district = district
    user.state = state
    user.pin = pin
    user.hash_password(password)

    db.session.add(user)
    db.session.commit()
    return ('',201)

@app.route('/authAddCycle', methods=['POST'])
@authOff.login_required
def authAddCycle():
    ownerId = request.json.get('cycleOwner')
    model = request.json.get('cycleModel')
    currentStation = request.json.get('cycleStationUsername')

    if ownerId is None or model is None or currentStation is None:
        abort(400)

    cycle = Cycle()
    cycle.ownerId = ownerId
    cycle.model = model
    cycle.currentStation = currentStation
    db.session.add(cycle)
    db.session.commit()

    return (str(cycle.id),201)

@app.route('/getMyProfile/<userId>')
def get_authUser(userId):
    user = AuthUser.query.filter_by(username=userId).first()
    if not user:
        abort(400)
    return jsonify({"username": user.username, "mobile" : user.mobile, "address" : user.address, "city" :user.city, "district" : user.district, "state" : user.state, "pin" : user.pin, "latitude":user.latitude, "longitude":user.longitude})


@app.route('/loginOff')
@authOff.login_required
def loginOff():
    return jsonify({'data': 'Hello, %s!' % g.user.username})


@app.route('/getCycles/<username>')
#@authOff.login_required
def getCycles(username):
    cycles = Cycle.query.filter_by(currentStation=username).all();
    cycleList = []
    for cycle in cycles:
        t = {"cycleId":str(cycle.id), "cycleModel": cycle.model,  "cycleOwner": cycle.ownerId, "status": cycle.status};
        cycleList.append(t);

    return jsonify(cycleList)

@app.route('/hello')
def hello():
    return "hello!\nCycleX API"

@app.route('/getStations')
def getStations():
    stations = AuthUser.query.filter_by().all();
    stationList = []
    for station in stations:
        t = {"username": station.username, "mobile" : station.mobile, "address" : station.address, "city" :station.city, "district" : station.district, "state" : station.state, "pin" : station.pin, "latitude":station.latitude, "longitude":station.longitude}
        stationList.append(t);

    return jsonify(stationList)



if __name__ == '__main__':
    db.create_all()
    app.run(host='0.0.0.0', debug=True)
