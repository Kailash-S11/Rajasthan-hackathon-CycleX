package com.laxmanmali.cylex;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
 EditText et_ip;
    Button btn_ip;
   public static String ip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_ip = (EditText)findViewById(R.id.et_ip);
        btn_ip= (Button) findViewById(R.id.btn_ip);



        btn_ip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ip = et_ip.getText().toString().trim();
                SharedPreferences settings = getSharedPreferences("HVI", 0); // 0 - for private mode
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("ip", ip);
                editor.apply();
                Log.i("jk", "onClick: "+ip);

                Intent i = new Intent(MainActivity.this,MainHome.class);
                startActivity(i);

            }
        });
    }
}
