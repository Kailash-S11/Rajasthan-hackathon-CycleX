package com.laxmanmali.cylex;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ShowDetail extends AppCompatActivity {
    TextView stationname,phone_no,acycle,ldistence,address1,link;
    Button submit;
    String user,phone ,address,distence;
    double latitude1, longitude1,latitude, longitude;
    GPSTracker gps;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_detail);

        gps = new GPSTracker(ShowDetail.this);
        latitude1 = gps.getLatitude();
        longitude1 = gps.getLongitude();
        Intent i = getIntent();
        Bundle b = i.getExtras();
        latitude = b.getDouble("latitude");
        longitude = b.getDouble("longitude");
         String title = b.getString("title");
        Log.i("TAG", "onCreate: ");

        String[] words=title.split(",");

        stationname = (TextView)findViewById(R.id.stationname);
        phone_no = (TextView)findViewById(R.id.phone_no);

        ldistence = (TextView)findViewById(R.id.ldistence);
        address1 = (TextView)findViewById(R.id.address);
        submit = (Button) findViewById(R.id.book);
        link = (TextView)findViewById(R.id.area_list);
        link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(android.content.Intent.ACTION_VIEW,
                        Uri.parse("http://maps.google.com/maps?saddr="+latitude1+","+longitude1+"&daddr="+latitude+","+longitude));
                startActivity(intent);
            }
        });


            stationname.setText(words[0]);
        address1.setText(words[1]);
        phone_no.setText(words[2]);
        String d =String.valueOf(distance(latitude1,longitude1,latitude,longitude));
        ldistence.setText(d);
     /*   for (int i1=0;i1<words.length;i1++) {
            Log.i("TAG", "onCreate: " + words[i1]+"\n "+i1 );
        }*/

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {




            }
        });
    }



    private double distance(double lat1, double lon1, double lat2, double lon2) {
        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);

        dist = dist * 60 * 1.1515;
        return (dist);
    }

    private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }

    private double rad2deg(double rad) {
        return (rad * 180.0 / Math.PI);
    }

}
