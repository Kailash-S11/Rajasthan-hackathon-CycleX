package com.laxmanmali.cylex;

import android.*;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.provider.Settings;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

public class SplashActivity extends AppCompatActivity {
    TextView lcancel, lsetting;
    Dialog dialog;
    private static int x = 2000;
    GPSTracker gps;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splace);



        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        if (Build.VERSION.SDK_INT >= 23
                && SplashActivity.this.checkSelfPermission(
                android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && SplashActivity.this.checkSelfPermission(
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION,
                            android.Manifest.permission.ACCESS_FINE_LOCATION}, 0);
        } else {

            location();

        }



    }





    void Conform() {
        dialog.setContentView(R.layout.location_conform);
        TextView lsetting, lcancel;
        lsetting = (TextView) dialog.findViewById(R.id.lsetting);

        lcancel = (TextView) dialog.findViewById(R.id.lcancel);


        lsetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Intent i = new Intent(SplashActivity.this, SplashActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                // Add new Flag to start new Activity
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                finish();

                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                SplashActivity.this.startActivity(intent);
            }
        });

        lcancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Intent intent = new Intent(Intent.ACTION_MAIN);

                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);//***Change Here***
                startActivity(intent);

                finish();

                System.exit(0);
            }
        });


        dialog.setCancelable(false);
        dialog.show();
    }


    void location() {

        dialog = new Dialog(SplashActivity.this);

        gps = new GPSTracker(SplashActivity.this);

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);


        if (gps.canGetLocation()) {


            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    // TODO Auto-generated method stub
                    // Intent i = new Intent(SplashActivity.this, LoginActivity.class);
                    Intent i = new Intent(SplashActivity.this, MainHome.class);
                    startActivity(i);
                    finish();
                }


            }, x);


        } else {

            Conform();

        }


    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        if (requestCode == 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            location();

        }
    }










}


