package com.laxmanmali.cylex;

/**
 * Created by LAXMAN MALI on 2/16/2017.
 */
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;




public class Home extends Fragment implements View.OnClickListener {
    String USER;
    View rootView;
    Button profile,rule,shareCycle,findS,bloodrequest,aboutus;
    ImageView profileimg,ruleimg,customizeimg,shareCycleimg,bloodimg;
    Boolean isInternetPresent = false;
    //ConnectionDetector cd;
    int k = 1;

    public void  inti ()

    {
        profile = (Button) rootView.findViewById(R.id.profile);
        findS = (Button) rootView.findViewById(R.id.findstore);




        // rule = (Button) rootView.findViewById(R.id.rule);
        // bloodrequest = (Button) rootView.findViewById(R.id.blood_requird);
        aboutus = (Button) rootView.findViewById(R.id.aboutus);
        shareCycle= (Button) rootView.findViewById(R.id.shareCycle);







        findS.setOnClickListener(this);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.home, container, false);


        inti();


        /*rootView.setFocusableInTouchMode(true);
        rootView.requestFocus();*/
       /* rootView.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event)   {
                if (keyCode == KeyEvent.KEYCODE_BACK) {





                        getActivity().finish();




                    return true;
                }
                return false;
            }
        });*/
        return rootView;


    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if(newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE)
        {
            profileimg.setPadding(0,0,0,0);
            ruleimg.setPadding(0,0,0,0);
            bloodimg.setPadding(0,0,0,0);

            customizeimg.setPadding(0,0,0,0);

            shareCycleimg.setPadding(0,0,0,0);


            RelativeLayout.LayoutParams rlp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
            rlp.addRule(RelativeLayout.CENTER_IN_PARENT,0);

            profileimg.setLayoutParams(rlp);
            ruleimg.setLayoutParams(rlp);
            bloodimg.setLayoutParams(rlp);

            customizeimg.setLayoutParams(rlp);

            shareCycleimg.setLayoutParams(rlp);


        }else if(newConfig.orientation == Configuration.ORIENTATION_PORTRAIT)
        {


            profileimg.setPadding(0,0,0,30);
            ruleimg.setPadding(0,0,0,30);
            bloodimg.setPadding(0,0,0,30);

            customizeimg.setPadding(0,0,0,30);

            shareCycleimg.setPadding(0,0,0,30);


            RelativeLayout.LayoutParams rlp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,RelativeLayout.LayoutParams.WRAP_CONTENT);
            rlp.addRule(RelativeLayout.CENTER_IN_PARENT,1);

            profileimg.setLayoutParams(rlp);
            ruleimg.setLayoutParams(rlp);
            bloodimg.setLayoutParams(rlp);

            customizeimg.setLayoutParams(rlp);

            shareCycleimg.setLayoutParams(rlp);

            // Toast.makeText(getActivity(),"portain1",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onClick(View v) {

        Fragment mFragment = null;
        FragmentManager mFragmentManager = getFragmentManager();

        switch (v.getId()) {

            case R.id.findstore:
                startActivity(new Intent(getActivity(),MapsActivity.class));
                break;

        }

        if (mFragment != null) {
            mFragmentManager.beginTransaction().replace(R.id.container, mFragment).addToBackStack(null).commit();
        }

    }
}





