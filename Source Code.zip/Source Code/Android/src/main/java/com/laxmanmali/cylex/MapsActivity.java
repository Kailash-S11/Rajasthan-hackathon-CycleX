package com.laxmanmali.cylex;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.NumberFormat;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    double latitude, longitude;

    /*    private ArrayList<LatLng> latlngs = new ArrayList<>();
        private ArrayList<String> name = new ArrayList<>();*/
    JSONArray peoples = null;
    String myJSON;
    private GoogleMap mMap;
    GPSTracker gps;
    ProgressDialog progress;
    CountDownTimer timer;
    NumberFormat formatter;
    private MarkerOptions options = new MarkerOptions();
    private void progressStuff() {
        // TODO Auto-generated method stub
        progress = new ProgressDialog(MapsActivity.this);
        progress.setMessage("Progressing...");
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progress.setCancelable(false);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getData();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        gps = new GPSTracker(MapsActivity.this);
        latitude = gps.getLatitude();
        longitude = gps.getLongitude();

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);








/*
        latlngs.add(new LatLng(26.447886, 74.701935));
        name.add("Govt Engineering college Ajmer");
        latlngs.add(new LatLng(26.400697, 74.661283 ));
        name.add("Govt Women Engineering college Ajmer");
        latlngs.add(new LatLng(26.469125, 74.644281  ));
        name.add("Bus Stand Ajmer");
        latlngs.add(new LatLng(26.457143, 74.637175));
        name.add("ajmer railway station");
        latlngs.add(new LatLng(26.468307, 74.635411));
        name.add("jln medical college");


        latlngs.add(new LatLng(26.475249, 74.633076));
        name.add("anasagar lake");
        latlngs.add(new LatLng(26.471395, 74.632369));
        name.add("bajrang garh");
        latlngs.add(new LatLng(26.474778, 74.652260));
        name.add("rbse ajmer");*/


    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera



        try {
            String title="";
            JSONArray jsonObj = new JSONArray(myJSON);
            int size = jsonObj.length();
            for(int i = 0; i < size; i++) {
                JSONObject temp = (JSONObject)jsonObj.get(i);
                Log.i("TAG", "showList: "+temp.get("latitude").toString()+temp.get("username").toString());
              /*  latlngs.add(new LatLng(Double.parseDouble(temp.get("latitude").toString()), Double.parseDouble(temp.get("longitude").toString())));
                name.add();*/

                title = temp.get("username").toString()+","+temp.get("address").toString()+"  "+temp.get("city").toString()+" "+temp.get("pin").toString()+","+temp.get("mobile").toString();
                mMap.addMarker(new MarkerOptions().position(new LatLng(Double.parseDouble(temp.get("latitude").toString()), Double.parseDouble(temp.get("longitude").toString()))).title( title  ));

            }
            LatLng   point=  new LatLng(latitude, longitude);
            Log.i("TAG", "onMapReady: "+latitude+longitude);
            Log.i("TAG", "onMapReady: "+point);
            mMap.addMarker(new MarkerOptions().position(point));
            CameraUpdate center=CameraUpdateFactory.newLatLng(point);
            CameraUpdate zoom=CameraUpdateFactory.zoomTo(13);
            mMap.moveCamera(center);
            mMap.animateCamera(zoom);
            mMap.addCircle(new CircleOptions()
                    .center(new LatLng(latitude, longitude))
                    .radius(1000)
                    .strokeColor(Color.BLUE).strokeWidth(2));




        } catch (JSONException e) {
            e.printStackTrace();
        }

      /*  Log.i("TAG", "onMapReady: "+latlngs+name);
        for (int  i=0;i<latlngs.size();i++) {

            Log.i("TAG", "onMapReady: "+latlngs.get(i)+name.get(i));

        }*/


        GoogleMap.OnMarkerClickListener listener = new GoogleMap.OnMarkerClickListener() {

            @Override
            public boolean onMarkerClick(final Marker marker) {
                Toast.makeText(MapsActivity.this,""+marker.getTitle(),Toast.LENGTH_LONG).show();

                LatLng position = marker.getPosition();
                Intent i = new Intent(MapsActivity.this, ShowDetail.class);
                Bundle b = new Bundle();
                b.putDouble("latitude", position.latitude);
                b.putDouble("longitude", position.longitude);
                b.putString("title", marker.getTitle());
                i.putExtras(b);
                startActivity(i);

                return true;
            }


        };

        mMap.setOnMarkerClickListener(listener);



        // mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }




    public void getData(){
        class GetDataJSON  extends AsyncTask {



            @Override
            protected void onPreExecute() {
                // TODO Auto-generated method stub
                super.onPreExecute();
                //  pd = ProgressDialog.show(ctx, "Please Wait", "Process running on server");

            }



            @Override
            protected Object doInBackground(Object... params) {

                //Toast.makeText(ctx,
                //	"Invalid username",
                //Toast.LENGTH_LONG).show();
                //Toast.makeText(ctx, "Inside ...doInBck", Toast.LENGTH_SHORT).show();
                Log.i("Inside................","do in Background");
                Log.v("Inside.....Background","1");
                String result="";

                SharedPreferences sharedPref = getSharedPreferences("HVI", 0);
                String ip = sharedPref.getString("ip", null);

                try{
                    String url = "http://172.16.39.203:5000/getStations";
                    Log.i("url", "doInBackground: "+ip);
                    Log.i("url", "doInBackground: "+url);
                 /*   String url="http://"+ new MainActivity().ip+"/getStations";
                 */
                    HttpURLConnection conn =
                            (HttpURLConnection) new URL(url).openConnection();
                    conn.setReadTimeout(25000);
                    conn.setConnectTimeout(25000);
                    conn.setRequestMethod("GET");   //

                    conn.connect();
                    Log.v("Inside.....Background","3");




                    BufferedReader reader =
                            new BufferedReader
                                    (new InputStreamReader(conn.getInputStream(), "UTF-8") );
                    String line = null;
                    Log.i("result1","4"+conn.getInputStream());
                    while ((line = reader.readLine()) != null)
                    {
                        result += line + "\n";
                    }
                    result=result.trim();

                    myJSON=result;
                    //    showList();
                    Log.i("result","4"+result);
                    conn.disconnect();

                }
                catch(Exception ex)
                {
                    Log.i("error",ex.getMessage());
                }
                return result;
            }





        }
        GetDataJSON g = new GetDataJSON();
        g.execute();
    }

    void location()


    {



        try {


            if (gps.canGetLocation()) {

                if (progress != null) {
                    progress.setMessage("Reading your Location...");
                    progress.show();
                }
                timer = new CountDownTimer(20000, 1000) {

                    @Override
                    public void onTick(long millisUntilFinished) {


                        latitude = gps.getLatitude();
                        longitude = gps.getLongitude();
                        //          Log.i("latitude1", "onTick: "+latitude+"Andr     "+ longitude);
                        if (!(latitude == 0.0 || longitude == 0.0))

                        {
                            timer.cancel();

                            Log.i("TAG", "111onTick: ");


                        }
                        //        Log.i("latitude1", "onTick: "+latitude+"Andr     "+ longitude);


                    }

                    @Override
                    public void onFinish() {
                        // TODO Auto-generated method stub
                        if (progress != null) {
                            progress.dismiss();

                        }
                        finish();
                        Toast.makeText(MapsActivity.this, "Unable to read location, please try again afther sometime....  ", Toast.LENGTH_LONG).show();

                    }

                }.start();
            } else {

                if (progress != null) {
                    progress.dismiss();

                }

                finish();
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                MapsActivity.this.startActivity(intent);


            }


        } catch (Exception e) {


            Toast.makeText(MapsActivity.this, "Unable to read location, please try again afther sometime....  ", Toast.LENGTH_LONG).show();


        }


    }






}
