/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cycleex01;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Base64;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 *
 * @author Kailash
 */
public class FXMLDocumentController implements Initializable {
    
    String credential, username, address;
    @FXML
    private JFXTextField userId;

    @FXML
    private JFXPasswordField userPassword;

    @FXML
    private JFXButton loginButton;
    
    @FXML
    private Label errorMsg;

    @FXML
    void login(ActionEvent event) {
        try {
            URL url = new URL("http://" +address + "/loginOff");
            HttpURLConnection con =  (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            String userpass = userId.getText() + ":" + userPassword.getText();
            String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userpass.getBytes()));
            this.credential = basicAuth;
            this.username = userId.getText();
            con.setRequestProperty ("Authorization", basicAuth);
            int responseCode = con.getResponseCode();
            System.out.println(responseCode);
            if (responseCode == 200) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                    response.append("\n");
                }
                in.close();
                System.out.println(response.toString());
                
                
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("HomePage.fxml"));
                    Parent homePage = loader.load();
                    Scene homePageScene = new Scene(homePage);
                    Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    appStage.setScene(homePageScene);
                    HomePageController controller = loader.<HomePageController>getController();
                    controller.setCredential(credential, username, address);
                    appStage.show();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                
                
            }else {
                errorMsg.setText("** Invalid Credential **");
            }
        } catch (MalformedURLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    
    public void setAddress(String address) {
        this.address = address;
    }
}
