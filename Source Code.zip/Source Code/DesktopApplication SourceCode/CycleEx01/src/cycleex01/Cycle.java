/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cycleex01;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author Kailash
 */
public class Cycle {
    private final int cycleId;
    private final SimpleStringProperty model;
    private final SimpleStringProperty owner;
    
    public Cycle(int cycleId, String model, String owner) {
        this.cycleId = cycleId;
        this.model = new SimpleStringProperty(model);
        this.owner = new SimpleStringProperty(owner);
    }
    
    public int getCycleId(){
        return this.cycleId;
    }
    
    public String getModel(){
        return this.model.get();
    }
    
    public String getOwner(){
        return this.owner.get();
    }
}
