/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cycleex01;

import java.io.File;
import java.io.PrintWriter;
import java.util.Optional;
import java.util.Scanner;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextInputDialog;
import javafx.stage.Stage;

/**
 *
 * @author Kailash
 */
public class CycleEx01 extends Application {
    String address;
    @Override
    public void start(Stage stage) throws Exception {
        try {
            File configFile = new File("conf.txt");
            if (configFile.exists()) {
                Scanner fileInput = new Scanner(configFile);
                if (fileInput.hasNext()) {
                    address = fileInput.nextLine();
                }
                System.out.println(address);
                fileInput.close();
            } else {
                
                TextInputDialog dialog = new TextInputDialog();
                dialog.setTitle("CycleX Api Address");
                dialog.setHeaderText(null);
                dialog.setContentText("Please enter address of CycleX API (e.g. 127.0.0.1:5000)");
                Optional<String> result = dialog.showAndWait();
                
                address = result.get();
                PrintWriter output = new PrintWriter(configFile);
                output.print(address);
                output.close();
                System.out.println(address);
            }
        } catch (Exception e) {

        }
		
        FXMLLoader loader = new FXMLLoader(getClass().getResource("FXMLDocument.fxml"));
        Parent root = loader.load();
        FXMLDocumentController controller = loader.<FXMLDocumentController>getController();
        controller.setAddress(address);
            
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
