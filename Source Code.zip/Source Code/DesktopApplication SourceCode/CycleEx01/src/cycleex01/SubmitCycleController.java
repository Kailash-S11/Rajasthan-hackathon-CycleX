/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cycleex01;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * FXML Controller class
 *
 * @author Kailash
 */
public class SubmitCycleController implements Initializable {

    String credential, username, address;
    
    @FXML
    private JFXTextField cycleId;

    @FXML
    private JFXButton btnSubmit;

    @FXML
    void submitCycle(ActionEvent event) {
        try {
            URL url = new URL("http://" + address + "/submitCycle/" + this.username + "/" + cycleId.getText());
            HttpURLConnection con =  (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty ("Authorization", credential);
            int responseCode = con.getResponseCode();
            System.out.println(responseCode);
            if (responseCode == 200) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                    response.append("\n");
                }
                in.close();
                JSONParser parser = new JSONParser();
                JSONObject obj = (JSONObject)parser.parse(response.toString());
                System.out.println(obj.toString()); 
                String detail = "***************Detail***************\n";
                detail += "USER Bhamashah Id\t:\t";
                detail += obj.get("bhamashahId").toString() + "\nMember Id   :   ";
                detail += obj.get("memberId").toString() + "\n";
                int temp;
                temp = Integer.parseInt(obj.get("years").toString());
                if( temp != 0)
                    detail += "YEARS\t:\t" + temp + "\n";
                temp = Integer.parseInt(obj.get("months").toString());
                if(temp != 0)
                    detail += "MONTHS\t:\t" + temp + "\n";
                temp = Integer.parseInt(obj.get("days").toString());
                if(temp != 0)
                    detail += "DAYS\t:\t" + temp + "\n";
                temp = Integer.parseInt(obj.get("hours").toString());
                if(temp != 0)
                    detail += "HOURS\t:\t" + temp + "\n";
                
                detail += "MINUTES\t:\t" + Integer.parseInt(obj.get("minutes").toString()) + "\n";
                
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Cycle Submit");
                alert.setHeaderText("Cycle Submitted Successfully!!");
                alert.setContentText(detail);
                alert.showAndWait();
            }
                
        } catch (MalformedURLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(SubmitCycleController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

    /**
     * Initializes the controller class.
     */
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    public void setCredential(String credential, String username, String address) {
        this.credential = credential;
        this.username = username;
        this.address = address;
    }
    
}
