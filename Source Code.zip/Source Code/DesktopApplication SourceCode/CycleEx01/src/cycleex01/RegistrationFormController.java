/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cycleex01;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * FXML Controller class
 *
 * @author Kailash
 */
public class RegistrationFormController implements Initializable {

    /**
     * Initializes the controller class.
     */
    String credential, username, address;
    final ToggleGroup tglGender = new ToggleGroup();
    @FXML
    private JFXTextField tfdFirstName;

    @FXML
    private JFXTextField tfdLastName;

    @FXML
    private RadioButton rbnMale;

    @FXML
    private RadioButton rbnFemale;

    @FXML
    private JFXTextField tfdEmail;

    @FXML
    private JFXTextField tfdMobile;

    @FXML
    private JFXTextField tfdAddress;

    @FXML
    private JFXTextField tfdCity;

    @FXML
    private JFXTextField tfdDistrict;

    @FXML
    private JFXButton btnRegister;

    @FXML
    private JFXButton btnReset;

    @FXML
    private JFXTextField tfdState;

    @FXML
    private JFXTextField tfdPinCode;

    @FXML
    private RadioButton rbnOther;

    @FXML
    private JFXPasswordField tfdPassword;

    @FXML
    private JFXPasswordField tfdConfPassword;

    @FXML
    void registerBtnClick(ActionEvent event) {
        try {
            String gender;
            if(rbnMale.isSelected())
                gender = "Male";
            else if(rbnFemale.isSelected())
                gender = "Female";
            else
                gender = "Other";
            
            String data = "{ \"firstName\": \"" + tfdFirstName.getText() +  "\",  \"lastName\": \"" + tfdLastName.getText() +  "\",  \"gender\": \"" + gender +  "\",  \"emailId\": \"" + tfdEmail.getText() +  "\",  \"mobileNo\": \"" + tfdMobile.getText() +  "\",  \"address\": \"" + tfdAddress.getText() +  "\",  \"city\": \"" + tfdCity.getText() +  "\",  \"district\": \"" + tfdDistrict.getText() +  "\",  \"state\": \"" + tfdState.getText() +  "\",  \"pin\": \"" + tfdPinCode.getText() +  "\",  \"password\":\"" + tfdPassword.getText() +  "\"}";
            
            System.out.println(data);
            
            URL url = new URL("http://" + address + "/addCli");
            String charset = "UTF-8";
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestProperty("Accept-Charset", charset);
            con.setDoOutput(true);
            con.setRequestProperty("Accept","application/json");    
            con.setRequestProperty("Content-Type", "application/json;charset=" + charset);
            con.setRequestMethod("POST");
            con.setRequestProperty ("Authorization", credential);
            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(data);
            System.out.println(json.toString());
            DataOutputStream out = new DataOutputStream(con.getOutputStream());
            out.writeBytes(json.toString());
            int rcode = con.getResponseCode();
            System.out.println(rcode);
            if(rcode == 201){
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Information Dialog");
                alert.setHeaderText(null);
                alert.setContentText("User Registration Successful!");
                alert.showAndWait();
            }
        } catch (MalformedURLException ex) {
            Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ProtocolException ex) {
            Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
        }

    
    }

    
    
    @FXML
    void resetBtnClick(ActionEvent event) {
        tfdFirstName.setText("");
        tfdLastName.setText("");
        rbnMale.setSelected(false);
        rbnFemale.setSelected(false);
        rbnOther.setSelected(false);
        tfdEmail.setText("");
        tfdMobile.setText("");
        tfdAddress.setText("");
        tfdCity.setText("");
        tfdDistrict.setText("");
        btnRegister.setText("");
        btnReset.setText("");
        tfdState.setText("");
        tfdPinCode.setText("");
        tfdPassword.setText("");
        tfdConfPassword.setText("");

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        rbnFemale.setToggleGroup(tglGender);
        rbnMale.setToggleGroup(tglGender);
        rbnOther.setToggleGroup(tglGender);
    }    
    
    public void setCredential(String credential, String username, String address) {
        this.credential = credential;
        this.username = username;
        this.address = address;
    }
    
}
