/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cycleex01;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * FXML Controller class
 *
 * @author Kailash
 */
public class TableController implements Initializable {

    String credential, username, address;
    @FXML
    private TableView<Cycle> tableView;
    @FXML
    private TableColumn<Cycle, Integer> cycleId;
    @FXML
    private TableColumn<Cycle, String> cycleModel;
    @FXML
    private TableColumn<Cycle, String> cycleOwner;
    
    
    ObservableList<Cycle> data;
    
    
    @FXML
    private ContextMenu contextMenu;

    @FXML
    private MenuItem menuItemIssue;

    @FXML
    void issueCycle(ActionEvent event) throws ParseException {
        Cycle cycle = tableView.getSelectionModel().getSelectedItem();
        
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("IssueWithBhamashah.fxml"));
            Parent root = loader.load();
            IssueWithBhamashahController controller = loader.<IssueWithBhamashahController>getController();
            controller.setCredential(credential, username, address, cycle.getCycleId() + "");
            Stage st = new Stage();
            Scene sn = new Scene(root);
            st.setScene(sn);
            st.showAndWait();
        } catch (IOException ex) {
            Logger.getLogger(HomePageController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        this.initializeTable();
        /*
        
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Bhamashah Id Input");
        dialog.setHeaderText(null);
        dialog.setContentText("Bhamashah ID");
            
        Optional<String> result = dialog.showAndWait();
        
        String bhamashahId = result.get();
        
        if (result.isPresent()) {
            
            
            
            System.out.println("Bhamashah Id : " + result.get());
            String issueData = "{ \"cycleId\": \"" + cycle.getCycleId() + "\",  \"fromStation\": \"" + username + "\",  \"Bhamashah Id\": \"" + bhamashahId + "\",  \"Bhamashah Id\": \"" + result.get() + "\"}";
            
            
            try {
                URL url = new URL("https://apitest.sewadwaar.rajasthan.gov.in/app/live/Service/hofAndMember/ForApp/" + bhamashahId + "?client_id=ad7288a4-7764-436d-a727-783a977f1fe1");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                
                int responseCode = con.getResponseCode();
                
                if (responseCode == 200) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String inputLine;
                    StringBuffer response = new StringBuffer();
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                in.close();
                
                JSONParser parser = new JSONParser();
                JSONObject json = (JSONObject) parser.parse(response.toString());
                JSONObject obj = (JSONObject)json.get("hof_Details");
                
                String bhamashahAckNumber = json.get("BHAMASHAH_ID").toString();
                JSONArray familyDetail = (JSONArray)json.get("family_Details");
                
                System.out.println(obj.toString());
                
                
                }
                
                
                
            } catch (MalformedURLException ex) {
                Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ProtocolException ex) {
                Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        
        
        */
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
    }    
    
    public void initializeTable() {
         data = FXCollections.observableArrayList();
         
        try {
            URL url1 = new URL("http://" + address + "/getCycles/" + username);
            
            HttpURLConnection con =  (HttpURLConnection)url1.openConnection();
            con.setRequestMethod("GET");
            //con.setRequestProperty ("Authorization", basicAuth);
            int responseCode = con.getResponseCode();
            if (responseCode == 200) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                JSONParser parser = new JSONParser();
                JSONArray json = (JSONArray) parser.parse(response.toString());
                int size = json.size();
                for(int i = 0; i < size; i++) {
                    JSONObject temp = (JSONObject )json.get(i);
                    if(Integer.parseInt(temp.get("status").toString()) == 0)
                        data.add(new Cycle(Integer.parseInt(temp.get("cycleId").toString()), temp.get("cycleModel").toString(), temp.get("cycleOwner").toString()));
                }
                
                cycleId.setCellValueFactory(
                    new PropertyValueFactory<Cycle,Integer>("cycleId")
                );
                
                cycleModel.setCellValueFactory(
                    new PropertyValueFactory<Cycle,String>("model")
                );
                
                cycleOwner.setCellValueFactory(
                    new PropertyValueFactory<Cycle,String>("owner")
                );
                
                tableView.getItems().setAll(data);
            }
        } catch (MalformedURLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(TableController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    public void setCredential(String credential, String username, String address) {
        this.credential = credential;
        this.username = username;
        this.address = address;
    }
    
}
