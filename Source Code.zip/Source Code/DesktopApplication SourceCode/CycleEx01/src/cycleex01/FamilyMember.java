
package cycleex01;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author Kailash
 */
public class FamilyMember {
    private final SimpleStringProperty aadhaarId;
    private final SimpleStringProperty dob;
    private final SimpleStringProperty mId;
    private final SimpleStringProperty address;
    private final SimpleStringProperty mobile;
    private final SimpleStringProperty name;
    
    public FamilyMember(String aadhaarId, String dob,  String mId, String address,  String mobile, String name) {
        this.aadhaarId = new SimpleStringProperty(aadhaarId);
        this.dob = new SimpleStringProperty(dob);
        this.mId = new SimpleStringProperty(mId);
        this.address = new SimpleStringProperty(address);
        this.mobile = new SimpleStringProperty(mobile);
        this.name = new SimpleStringProperty(name);
    }
    
    public String getAadhaarId(){
        return this.aadhaarId.get();
    }
    
    public String getDob(){
        return this.dob.get();
    }
    
    public String getMId(){
        return this.mId.get();
    }
    
    public String getAddress(){
        return this.address.get();
    }
    
    public String getMobile(){
        return this.mobile.get();
    }
    public String getName(){
        return this.name.get();
    }
}
