/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cycleex01;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.cell.PropertyValueFactory;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * FXML Controller class
 *
 * @author Kailash
 */
public class ProfileController implements Initializable {

    String credential, username, address;
    @FXML
    private JFXTextField tfdStationId;
    @FXML
    private JFXTextField tfdContactNumber;
    @FXML
    private JFXTextField tfdAddress;
    @FXML
    private JFXTextField tfdCity;
    @FXML
    private JFXTextField tfdDistrict;
    @FXML
    private JFXTextField tfdState;
    @FXML
    private JFXTextField tfdPinCode;
    @FXML
    private JFXTextField tfdLatitude;
    @FXML
    private JFXTextField tfdLongitude;
    @FXML
    private JFXButton btnSubmit;
    @FXML
    private JFXButton btnSubmit1;
    @FXML
    private JFXButton btnSubmit11;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void submitCycle(ActionEvent event) {
        
    }

    @FXML
    private void updatePassword(ActionEvent event) {
    
    }

    @FXML
    private void reset(ActionEvent event) {
        
                
    }
    
    public void initProfile(){
        try {
            URL url1 = new URL("http://" + address + "/getMyProfile/" + username);
            
            HttpURLConnection con =  (HttpURLConnection)url1.openConnection();
            con.setRequestMethod("GET");
            //con.setRequestProperty ("Authorization", basicAuth);
            int responseCode = con.getResponseCode();
            if (responseCode == 200) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                JSONParser parser = new JSONParser();
                JSONObject json = (JSONObject) parser.parse(response.toString());
                
                tfdStationId.setText(json.get("username").toString());
                tfdContactNumber.setText(json.get("mobile").toString());
                tfdAddress.setText(json.get("address").toString());
                tfdCity.setText(json.get("city").toString());
                tfdDistrict.setText(json.get("district").toString());
                tfdState.setText(json.get("state").toString());
                tfdPinCode.setText(json.get("pin").toString());
                tfdLatitude.setText(json.get("latitude").toString());
                tfdLongitude.setText(json.get("longitude").toString());
                
                tfdStationId.setEditable(false);
                
            }
        } catch (MalformedURLException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(TableController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void setCredential(String credential, String username, String address) {
        this.credential = credential;
        this.username = username;
        this.address = address;
    }
}
