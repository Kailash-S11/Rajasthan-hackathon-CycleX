/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cycleex01;

import com.jfoenix.controls.JFXButton;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Kailash
 */
public class HomePageController implements Initializable {

    /**
     * Initializes the controller class.
     */
    String credential, username, address;
    
    @FXML
    private BorderPane homeBorderLayout;

    @FXML
    private JFXButton btnProfile;

    @FXML
    private JFXButton btnAvailableCycle;

    @FXML
    private JFXButton btnNewUserReg;

    @FXML
    private JFXButton btnAddCycle;

    @FXML
    private JFXButton btnissueCycle;

    @FXML
    private JFXButton btnSubmitCycle;

    @FXML
    private JFXButton btnExit;
    
    @FXML
    private MenuItem menuBtnChangeAddress;

    @FXML
    private JFXButton btnLogOut;
    
    @FXML
    void logOut(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("FXMLDocument.fxml"));
            Parent root = loader.load();
            FXMLDocumentController controller = loader.<FXMLDocumentController>getController();
            controller.setAddress(address);
            Stage st = (Stage)btnLogOut.getScene().getWindow();
            Scene sn = new Scene(root);
            st.setScene(sn);
            st.show();
        } catch (IOException ex) {
            Logger.getLogger(HomePageController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void setCredential(String credential, String username, String address) {
        this.credential = credential;
        this.username = username;
        this.address = address;
    }
        
    @FXML
    void chageAddress(ActionEvent event) {
        PrintWriter output = null;
        try {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("CycleX API Address (**Application restart required)");
            dialog.setHeaderText(null);
            dialog.setContentText("Please enter new address of CycleX API:");
            Optional<String> result = dialog.showAndWait();
            File configFile = new File("conf.txt");
            output = new PrintWriter(configFile);
            output.print(result.get());
            output.close();
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(HomePageController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            output.close();
        }
    }

    @FXML
    void exitHome(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void viewCycles(ActionEvent event) {
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Table.fxml"));
            Node root = loader.load();
            homeBorderLayout.setCenter(root);
            TableController controller = loader.<TableController>getController();
            controller.setCredential(credential, username, address);
            controller.initializeTable();
        } catch (IOException ex) {
            Logger.getLogger(HomePageController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void viewProfile(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Profile.fxml"));
            Node root = loader.load();
            homeBorderLayout.setCenter(root);
            ProfileController controller = loader.<ProfileController>getController();
            controller.setCredential(credential, username, address);
            controller.initProfile();
        } catch (IOException ex) {
            Logger.getLogger(HomePageController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void viewRegForm(ActionEvent event) {
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("RegistrationForm.fxml"));
            Node root = loader.load();
            //root.boundsInParentProperty();
            homeBorderLayout.setCenter(root);
            //btnAvailableCycle.setStyle("-fx-background-color: #1B4F72;");
            
            RegistrationFormController controller = loader.<RegistrationFormController>getController();
            controller.setCredential(credential, username, address);
        } catch (IOException ex) {
            Logger.getLogger(HomePageController.class.getName()).log(Level.SEVERE, null, ex);
        }

        
    }

    @FXML
    void addCycle(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AddCycle.fxml"));
            Node root = loader.load();
            homeBorderLayout.setCenter(root);
            AddCycleController controller = loader.<AddCycleController>getController();
            controller.setCredential(credential, username, address);
        } catch (IOException ex) {
            Logger.getLogger(HomePageController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void issueCycle(ActionEvent event) {
        
    }

    @FXML
    void submitCycle(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("SubmitCycle.fxml"));
            Node root = loader.load();
            homeBorderLayout.setCenter(root);
            SubmitCycleController controller = loader.<SubmitCycleController>getController();
            controller.setCredential(credential, username, address);
        } catch (IOException ex) {
            Logger.getLogger(HomePageController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        //System.out.println("hey");
    }    
    
}
