/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cycleex01;

import com.jfoenix.controls.JFXTextField;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Base64;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * FXML Controller class
 *
 * @author Kailash
 */
public class IssueWithBhamashahController implements Initializable {
    String credential, username, address, cycleId;
    ObservableList<FamilyMember> familyList;
    String bhamashahId;
    String bhamashahAckNumber;
    @FXML
    private ImageView imageView;
    @FXML
    private Button getImage;
    
    @FXML
    private JFXTextField bhamFNo;
    @FXML
    private TableView<FamilyMember> memberTable;

    @FXML
    private TableColumn<FamilyMember, String> aadhaarField;

    @FXML
    private Button btnIssueCycle;

    
    @FXML
    private TableColumn<FamilyMember, String> memberId;

    @FXML
    private TableColumn<FamilyMember, String> memberName;

    @FXML
    private TableColumn<FamilyMember, String> dobField;

    @FXML
    private TableColumn<FamilyMember, String> mobileField;

    @FXML
    private TableColumn<FamilyMember, String> addressField;

    
    public void setCredential(String credential, String username, String address, String cycleId) {
        this.credential = credential;
        this.username = username;
        this.address = address;
        this.cycleId = cycleId;
    }

    /**
     * Initializes the controller class.
     */
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
    
    @FXML
    void issueCycle(ActionEvent event) {
        String memberId = memberTable.getSelectionModel().getSelectedItem().getMId();
        String issueData = "{ \"cycleId\": \"" + cycleId + "\",  \"fromStation\": \"" + username + "\",  \"bhamashahId\": \"" + bhamashahId + "\",  \"memberId\": \"" + memberId + "\"}";
            try {
                URL url = new URL("http://" + address + "/issueCycle");
                String charset = "UTF-8";
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestProperty("Accept-Charset", charset);
                con.setDoOutput(true);
                con.setRequestProperty("Accept", "application/json");
                con.setRequestProperty("Content-Type", "application/json;charset=" + charset);
                con.setRequestMethod("POST");
                con.setRequestProperty("Authorization", credential);
                JSONParser parser = new JSONParser();
                JSONObject json = (JSONObject) parser.parse(issueData);
                System.out.println(json.toString());
                DataOutputStream out = new DataOutputStream(con.getOutputStream());
                out.writeBytes(json.toString());
                int rcode = con.getResponseCode();
                System.out.println(rcode);
                if (rcode == 201) {
                    
                    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String inputLine;
                    StringBuffer response = new StringBuffer();
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    in.close();
                    
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information Dialog");
                    alert.setHeaderText(null);
                    alert.setContentText("Cycles Issued Successfully!\n\nCycle Id\t:\t" + response.toString());
                    alert.showAndWait();
                    
                }else if(rcode == 202) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information Dialog");
                    alert.setHeaderText(null);
                    alert.setContentText("Cycle already issued to this user\nBhamashah Family Id  :   " + bhamashahId + "   Member Id  :  " + memberId);
                    alert.showAndWait();
                }
                
                
            } catch (MalformedURLException ex) {
                Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ProtocolException ex) {
                Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ParseException ex) {
                Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            ((Button)(event.getSource())).getScene().getWindow().hide();
        
    }
    
    @FXML
    void getImage(ActionEvent event) {
        System.out.println("hey x");
        FamilyMember fm = memberTable.getSelectionModel().getSelectedItem();
        URL url;
        try {
            url = new URL("https://apitest.sewadwaar.rajasthan.gov.in/app/live/Service/hofMembphoto/" + bhamashahAckNumber + "/" + fm.getMId() +  "?client_id=ad7288a4-7764-436d-a727-783a977f1fe1");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            
            int responseCode = con.getResponseCode();
            
            System.out.println(url);
            if (responseCode == 200) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                System.out.println(response);
                in.close();

                JSONParser parser = new JSONParser();
                JSONObject json = (JSONObject) parser.parse(response.toString());
                String value;
                byte[] imgBytes;
                if(json.containsKey("member_Photo")){
                    value = ((JSONObject) ((JSONArray) json.get("member_Photo")).get(0)).get("PHOTO").toString();
                    imgBytes = Base64.getDecoder().decode(value);
                }else {
                    value =  ((JSONObject) json.get("hof_Photo")).get("PHOTO").toString();
                    imgBytes = Base64.getDecoder().decode(value);
                }
                imageView.setImage(new Image(new ByteArrayInputStream(imgBytes)));
       
            }
        
        } catch (MalformedURLException ex) {
            Logger.getLogger(IssueWithBhamashahController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(IssueWithBhamashahController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(IssueWithBhamashahController.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        
    }
    
    @FXML
    private void getBhamashahFNo(ActionEvent event) {
        bhamashahId = bhamFNo.getText();
        
        familyList = FXCollections.observableArrayList();
        System.out.println("hey");
        try {
            URL url = new URL("https://apitest.sewadwaar.rajasthan.gov.in/app/live/Service/hofAndMember/ForApp/" + bhamashahId + "?client_id=ad7288a4-7764-436d-a727-783a977f1fe1");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();

            int responseCode = con.getResponseCode();

            if (responseCode == 200) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                JSONParser parser = new JSONParser();
                JSONObject json = (JSONObject) parser.parse(response.toString());
                JSONObject obj = (JSONObject) json.get("hof_Details");
                
                
                System.out.println("obj : " + obj.toString());
                
                bhamashahAckNumber = obj.get("BHAMASHAH_ID").toString();
                /*
                if(obj.get("MOBILE_NO") == null)
                        mobileNo = "Not";
                    else
                        mobileNo = obj.get("MOBILE").toString();
                System.out.println(mobileNo);
                familyList.add(new FamilyMember(obj.get("AADHAR_ID").toString(), obj.get("DOB").toString(), obj.get("M_ID").toString(), obj.get("ADDRESS").toString(), mobileNo, obj.get("NAME_ENG").toString()));
                */    
                JSONArray familyDetail = (JSONArray) json.get("family_Details");
                System.out.println("hey");
                System.out.println(obj.toString());
                
                
                int size = familyDetail.size();
                System.out.println(size);
                
                JSONObject temp;
                String mobileNo;
                String aadhaar;
                String dob;
                String mId;
                String address;
                String name;
                
                if (obj.get("MOBILE") == null) {
                    mobileNo = "Not Available";
                } else {
                    mobileNo = obj.get("MOBILE").toString();
                }

                if (obj.get("AADHAR_ID") == null) {
                    aadhaar = "Not Available";
                } else {
                    aadhaar = obj.get("AADHAR_ID").toString();
                }

                if (obj.get("DOB") == null) {
                    dob = "Not Available";
                } else {
                    dob = obj.get("DOB").toString();
                }

                if (obj.get("M_ID") == null) {
                    mId = "Not Available";
                } else {
                    mId = obj.get("M_ID").toString();
                }

                if (obj.get("ADDRESS") == null) {
                    address = "Not Available";
                } else {
                    address = obj.get("ADDRESS").toString();
                }

                if (obj.get("NAME_ENG") == null) {
                    name = "Not Available";
                } else {
                    name = obj.get("NAME_ENG").toString();
                }

                    
                familyList.add(new FamilyMember(aadhaar, dob, mId, address, mobileNo, name));
                
                //for (int i = 0; i < 2; i++) {
                //    System.out.println(i);
                //    temp = (JSONObject)familyDetail.get(i);
                
                for(Object temp1: familyDetail){
                    temp = (JSONObject)temp1;
                    if(temp.get("MOBILE") == null)
                        mobileNo = "Not Available";
                    else
                        mobileNo = temp.get("MOBILE").toString();
                    
                    if(temp.get("MEMBER_AADHAR_ID") == null)
                        aadhaar = "Not Available";
                    else
                        aadhaar = temp.get("MEMBER_AADHAR_ID").toString();
                    
                    if(temp.get("DOB") == null)
                        dob = "Not Available";
                    else
                        dob = temp.get("DOB").toString();
                    
                    if(temp.get("M_ID") == null)
                        mId = "Not Available";
                    else
                        mId = temp.get("M_ID").toString();
                    
                    if(temp.get("ADDRESS") == null)
                        address = "Not Available";
                    else
                        address = temp.get("ADDRESS").toString();
                    
                    if(temp.get("NAME_ENG") == null)
                        name = "Not Available";
                    else
                        name = temp.get("NAME_ENG").toString();
                    
                    
                    
                    familyList.add(new FamilyMember(aadhaar, dob, mId, address, mobileNo, name));
                    System.out.println("heyy");
                }
                
                System.out.println("hddf");
                aadhaarField.setCellValueFactory(
                    new PropertyValueFactory<FamilyMember,String>("aadhaarId")
                );
                
                memberId.setCellValueFactory(
                    new PropertyValueFactory<FamilyMember,String>("mId")
                );
                
                memberName.setCellValueFactory(
                    new PropertyValueFactory<FamilyMember,String>("name")
                );
                
                dobField.setCellValueFactory(
                    new PropertyValueFactory<FamilyMember,String>("dob")
                );
                
                mobileField.setCellValueFactory(
                    new PropertyValueFactory<FamilyMember,String>("mobile")
                );
                
                addressField.setCellValueFactory(
                    new PropertyValueFactory<FamilyMember,String>("address")
                );
                
                memberTable.getItems().setAll(familyList);
                
                
            }


                
            } catch (MalformedURLException ex) {
                Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ProtocolException ex) {
                Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(RegistrationFormController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ParseException ex) {
            Logger.getLogger(IssueWithBhamashahController.class.getName()).log(Level.SEVERE, null, ex);
        }

        
    }
    
}
