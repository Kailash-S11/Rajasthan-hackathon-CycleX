/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cycleex01;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * FXML Controller class
 *
 * @author Kailash
 */
public class AddCycleController implements Initializable {

    /**
     * Initializes the controller class.
     */
    String credential, username, address;
    @FXML
    private JFXTextField cycleModel;

    @FXML
    private JFXTextField cycleOwnerId;

    @FXML
    private JFXButton btnAdd;

    @FXML
    private JFXButton btnReset;

    @FXML
    void addCycle(ActionEvent event) {
        try {
            String data = "{ \"cycleModel\": \"" + cycleModel.getText() + "\",  \"cycleOwner\": \"" + cycleOwnerId.getText() + "\",  \"cycleStationUsername\": \"" + this.username + "\" }";
            System.out.println(data);
            URL url = new URL("http://" + address + "/authAddCycle");
            String charset = "UTF-8";
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestProperty("Accept-Charset", charset);
            con.setDoOutput(true);
            con.setRequestProperty("Accept", "application/json");
            con.setRequestProperty("Content-Type", "application/json;charset=" + charset);
            con.setRequestMethod("POST");
            con.setRequestProperty("Authorization", credential);
            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(data);
            System.out.println(json.toString());
            DataOutputStream out = new DataOutputStream(con.getOutputStream());
            out.writeBytes(json.toString());
            int rcode = con.getResponseCode();
            System.out.println(rcode);
            if (rcode == 201) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information Dialog");
                alert.setHeaderText(null);
                alert.setContentText("Cycle added successfully!\n\nGenerated Cycle Id\t:\t" + response.toString());
                alert.showAndWait();
            }
        } catch (IOException ex) {
            Logger.getLogger(AddCycleController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(AddCycleController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void resetForm(ActionEvent event) {
        this.cycleModel.setText("");
        this.cycleOwnerId.setText("");
    }
    public void setCredential(String credential, String username, String address) {
        this.credential = credential;
        this.username = username;
        this.address = address;
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
